local REQUIRED_ENEMIES = 3

local SHOW_TEST_HINTS = true

function PlayerMovement:_upd_underdog_skill(t)
    local data = self._underdog_skill_data

    if not data or
        not (data.has_dmg_mul or data.has_dmg_dampener or data.has_dmg_dampener_close) or
        t < (data.chk_t or 0) then
        return
    end

    data.nr_enemies = REQUIRED_ENEMIES
    local nearby = 0
    local my_pos = self._m_pos
    local all_enemies = managers.enemy and managers.enemy:all_enemies() or {}

    if my_pos then
        for _, enemy_data in pairs(all_enemies) do
            local enemy = enemy_data.unit

            if alive(enemy) and not enemy:in_slot(16) then
                local movement = enemy:movement()
                local enemy_pos = movement and movement.m_pos and movement:m_pos()

                if enemy_pos and
                    mvector3.distance_sq(enemy_pos, my_pos) < data.max_dis_sq and
                    math.abs(enemy_pos.z - my_pos.z) < data.max_vert_dis then
                    nearby = nearby + 1

                    if nearby >= REQUIRED_ENEMIES then
                        break
                    end
                end
            end
        end
    end

    local in_range = nearby >= REQUIRED_ENEMIES

    if in_range then
        if data.has_dmg_mul then
            managers.player:activate_temporary_upgrade("temporary", "dmg_multiplier_outnumbered")
        end

        if data.has_dmg_dampener then
            managers.player:activate_temporary_upgrade("temporary", "dmg_dampener_outnumbered")
            managers.player:activate_temporary_upgrade("temporary", "dmg_dampener_outnumbered_strong")
        end
    end

    if data.has_dmg_dampener_close and nearby >= 1 then
        managers.player:activate_temporary_upgrade("temporary", "dmg_dampener_close_contact")
    end

    if SHOW_TEST_HINTS and self._underdog_proximity_previous ~= in_range then
        self._underdog_proximity_previous = in_range

        if managers.hud and managers.hud.show_hint then
            managers.hud:show_hint({
                text = in_range and "Underdog proximity: IN RANGE" or "Underdog proximity: OUT OF RANGE",
                time = 2
            })
        end
    end

    data.chk_t = t + (in_range and data.chk_interval_active or data.chk_interval_inactive)
end
